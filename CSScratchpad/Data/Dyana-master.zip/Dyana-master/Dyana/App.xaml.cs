using System.Windows;

namespace Dyana {
    public partial class App : Application { }
}
